package com.wind.cache.andfixproject;

public class RightMethodClass {

    public int fixGet(int a, int b) {
        return a+b+100000;
    }

}
