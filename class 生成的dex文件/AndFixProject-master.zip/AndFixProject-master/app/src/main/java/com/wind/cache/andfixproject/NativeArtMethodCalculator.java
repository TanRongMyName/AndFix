package com.wind.cache.andfixproject;

public class NativeArtMethodCalculator {
    public static void method1(){}
    public static void method2(){}
}
